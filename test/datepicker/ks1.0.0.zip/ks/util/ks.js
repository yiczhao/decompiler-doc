define(function() {
    var KS = function() {
        
    }
    return KS
})
